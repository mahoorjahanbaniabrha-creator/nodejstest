// Build step: fails if a required environment variable is missing.
const fs = require("fs");

const REQUIRED = "MY_REQUIRED_VAR";
const value = process.env[REQUIRED];

console.log("Starting build...");

if (!value || value.trim() === "") {
  console.error(`\nError: environment variable ${REQUIRED} is not defined.`);
  console.error(`Add ${REQUIRED} in the app's environment variables and redeploy.\n`);
  process.exit(1); // non-zero exit code = build failed
}

// Bake the value into the build output, like a build-time variable would be.
fs.mkdirSync("dist", { recursive: true });
fs.writeFileSync("dist/config.json", JSON.stringify({ value }, null, 2));

console.log(`${REQUIRED} found. Build succeeded.`);
