const http = require("http");
const config = require("./dist/config.json");

const port = process.env.PORT || 3000;

http
  .createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end(`App is running. MY_REQUIRED_VAR = ${config.value}\n`);
  })
  .listen(port, "0.0.0.0", () => console.log(`Listening on port ${port}`));
